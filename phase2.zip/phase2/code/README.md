Course Project
==============

#### CS 583 Probabilistic Graphic Model

### Programming language

* Python


### Dependencies:

* `csv` for reading/writing
* `logging` and `python_log_indenter` for pretty console message
* `numpy` for numerical/matrix operations
* `matplotlib` for figure plotting
* `statsmodels` for linear regression
* `python_log_indenter` for indented logging output

